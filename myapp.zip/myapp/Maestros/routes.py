from flask import Blueprint
from flask import Flask, redirect, render_template
from flask import request
from flask import url_for
import forms
from flask import jsonify
from config import DevelopmentConfig
from flask_wtf.csrf import CSRFProtect
from db import get_connection
from models import Maestros
app=Flask(__name__)
app.config['DEBUG']=True
app.config.from_object(DevelopmentConfig)
csrf=CSRFProtect()

maestros=Blueprint('maestros',__name__)

@maestros.route('/getmaes',methods=['GET'])
def getmaes():
    create_form=forms.UseForm(request.form)
    maestros=[]
    try:
        connection=get_connection()
        with connection.cursor() as cursor:
            cursor.execute("CALL consultar_maestros()")
            resutset=cursor.fetchall()
            for row in resutset:
                maes=Maestros(id=row[0],
                    nombre=row[1],
                    apellidos=row[2],
                    email=row[3])
                maestros.append(maes)
    except Exception as ex:
        print('ERROR')
    return render_template('ABCompleto1.html',form=create_form,maestros=maestros)


@maestros.route("/agregar1", methods=['GET','POST'])
def agregar1():
    create_form=forms.UseForm(request.form)
    if request.method=='POST' and create_form.validate():
        try:
            connection=get_connection()
            with connection.cursor() as cursor:
                cursor.execute('CALL agrega_maestro(%s,%s,%s)',(create_form.nombre.data,create_form.apellidos.data,create_form.email.data))
            connection.commit()
            connection.close()
        except Exception as ex:
            print('ERROR')
        return redirect(url_for('maestros.getmaes'))
    return render_template('agregar1.html',form=create_form)

@maestros.route("/modificar1",methods=['GET','POST'])
def modificar1():
    create_form=forms.UseForm(request.form)
    if request.method=='GET':
        id=request.args.get('id')
        try:
            connection=get_connection()
            with connection.cursor() as cursor:
                cursor.execute('CALL consultar_maestro(%s)',(id,))
                resutset=cursor.fetchall()
                for row in resutset:
                    maes1=Maestros(id=row[0],
                        nombre=row[1],
                        apellidos=row[2],
                        email=row[3])
        except Exception as ex:
            print('ERROR')
        create_form.id.data=request.args.get('id')
        create_form.nombre.data=maes1.nombre
        create_form.apellidos.data=maes1.apellidos
        create_form.email.data=maes1.email
    if request.method=='POST' and create_form.validate():
        try:
            connection=get_connection()
            with connection.cursor() as cursor:
                cursor.execute('CALL modificar_maestro(%s,%s,%s,%s)',(create_form.id.data,create_form.nombre.data,create_form.apellidos.data,create_form.email.data))
            connection.commit()
            connection.close()
        except Exception as ex:
            print('ERROR')
        return redirect(url_for('maestros.getmaes'))
    return render_template('modificar1.html',form=create_form)

@maestros.route("/eliminar1",methods=['GET','POST'])
def eliminar1():
    create_form=forms.UseForm(request.form)
    if request.method=='GET':
        id=request.args.get('id')
        try:
            connection=get_connection()
            with connection.cursor() as cursor:
                cursor.execute('CALL consultar_maestro(%s)',(id,))
                resutset=cursor.fetchall()
                for row in resutset:
                    maes1=Maestros(id=row[0],
                        nombre=row[1],
                        apellidos=row[2],
                        email=row[3])
        except Exception as ex:
            print('ERROR')
        create_form.id.data=request.args.get('id')
        create_form.nombre.data=maes1.nombre
        create_form.apellidos.data=maes1.apellidos
        create_form.email.data=maes1.email
    if request.method=='POST':
        try:
            connection=get_connection()
            with connection.cursor() as cursor:
                cursor.execute('CALL eliminar_maestro(%s)',(create_form.id.data))
            connection.commit()
            connection.close()
        except Exception as ex:
            print('ERROR')
        return redirect(url_for('maestros.getmaes'))
    return render_template('eliminar1.html',form=create_form)  